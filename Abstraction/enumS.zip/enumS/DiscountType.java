package Abstraction.enumS;

public enum DiscountType {
    VIP("Vip",20),
    SECONDVISIT("SecondVisit",10),
    NONE("None",0);
    private String kind;

    private double percent;

    DiscountType(String kind, double percent) {
        this.kind = kind;
        this.percent = percent;
    }

    public String getKind() {
        return kind;
    }

    public void setKind(String kind) {
        this.kind = kind;
    }

    public double getPercent() {
        return percent;
    }

    public void setPercent(double percent) {
        this.percent = percent;
    }
}
