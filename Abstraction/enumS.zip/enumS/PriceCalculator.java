package Abstraction.enumS;

public class PriceCalculator {

    public static double calculateHolidayPrice(double pricePerDay, int days, Season season, DiscountType discountType) {
        double sum = pricePerDay * days;

        sum =sum* season.getMultiplyCoefficient();

        sum=sum - sum*(discountType.getPercent()/100);

        return sum;
    }

}
