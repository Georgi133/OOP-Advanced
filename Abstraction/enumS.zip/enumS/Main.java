package Abstraction.enumS;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        String [] kindOfVacation =scanner.nextLine().split("\\s+");

        double pricePerDay = Double.parseDouble(kindOfVacation[0]);

        int numberOfDays=Integer.parseInt(kindOfVacation[1]);

        Season season =Season.valueOf(kindOfVacation[2].toUpperCase());

        DiscountType discountType= DiscountType.valueOf(kindOfVacation[3].toUpperCase());

        double price = PriceCalculator.calculateHolidayPrice(pricePerDay,numberOfDays,season,discountType);

        System.out.printf("%.2f",price);



    }
}
